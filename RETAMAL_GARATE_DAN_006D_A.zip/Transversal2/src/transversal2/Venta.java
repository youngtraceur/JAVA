/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package transversal2;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Venta {
    private Cliente cliente;
    private Equipo equipo;
    private Date fechaHora;

    public Venta(Cliente cliente, Equipo equipo) {
        this.cliente = cliente;
        this.equipo = equipo;
        this.fechaHora = new Date();
    }

    // Getter methods
    public Cliente getCliente() {
        return cliente;
    }

    public Equipo getEquipo() {
        return equipo;
    }

    public String getFechaHora() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return dateFormat.format(fechaHora);
    }
}