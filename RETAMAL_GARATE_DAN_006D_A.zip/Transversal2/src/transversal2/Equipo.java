/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package transversal2;
public class Equipo {
    private String modelo;
    private String tipo; // "Desktop" o "Laptop"
    private int potenciaFuente; // Solo para Desktop
    private String factorForma; // Solo para Desktop
    private double tamanoPantalla; // Solo para Laptop
    private int cantidadPuertosUSB; // Solo para Laptop
    private String cpu;
    private int tamanoDisco;
    private int cantidadRam;
    private double precio;

    public Equipo(String modelo, String tipo, int potenciaFuente, String factorForma,
                  double tamanoPantalla, int cantidadPuertosUSB, String cpu, int tamanoDisco,
                  int cantidadRam, double precio) {
        this.modelo = modelo;
        this.tipo = tipo;
        this.potenciaFuente = potenciaFuente;
        this.factorForma = factorForma;
        this.tamanoPantalla = tamanoPantalla;
        this.cantidadPuertosUSB = cantidadPuertosUSB;
        this.cpu = cpu;
        this.tamanoDisco = tamanoDisco;
        this.cantidadRam = cantidadRam;
        this.precio = precio;
    }

    // Getters y setters detallados

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getPotenciaFuente() {
        return potenciaFuente;
    }

    public void setPotenciaFuente(int potenciaFuente) {
        this.potenciaFuente = potenciaFuente;
    }

    public String getFactorForma() {
        return factorForma;
    }

    public void setFactorForma(String factorForma) {
        this.factorForma = factorForma;
    }

    public double getTamanoPantalla() {
        return tamanoPantalla;
    }

    public void setTamanoPantalla(double tamanoPantalla) {
        this.tamanoPantalla = tamanoPantalla;
    }

    public int getCantidadPuertosUSB() {
        return cantidadPuertosUSB;
    }

    public void setCantidadPuertosUSB(int cantidadPuertosUSB) {
        this.cantidadPuertosUSB = cantidadPuertosUSB;
    }

    public String getCpu() {
        return cpu;
    }

    public void setCpu(String cpu) {
        this.cpu = cpu;
    }

    public int getTamanoDisco() {
        return tamanoDisco;
    }

    public void setTamanoDisco(int tamanoDisco) {
        this.tamanoDisco = tamanoDisco;
    }

    public int getCantidadRam() {
        return cantidadRam;
    }

    public void setCantidadRam(int cantidadRam) {
        this.cantidadRam = cantidadRam;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }
}