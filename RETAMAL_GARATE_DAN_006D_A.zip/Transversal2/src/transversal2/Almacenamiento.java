/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package transversal2;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Almacenamiento {
    private List<Cliente> clientes;
    private List<Equipo> equipos;
    private List<Venta> ventas;

    public Almacenamiento() {
        this.clientes = new ArrayList<>();
        this.equipos = new ArrayList<>();
        this.ventas = new ArrayList<>();
    }

    // Métodos para agregar, obtener y buscar clientes, equipos y ventas

    // Métodos para clientes
    public void agregarCliente(Cliente cliente) {
        clientes.add(cliente);
    }

    public Cliente obtenerClientePorRut(String rut) {
        for (Cliente cliente : clientes) {
            if (cliente.getRut().equals(rut)) {
                return cliente;
            }
        }
        return null;
    }

    // Métodos para equipos
    public void agregarEquipo(Equipo equipo) {
        equipos.add(equipo);
    }

    public Equipo obtenerEquipoPorModelo(String modelo) {
        for (Equipo equipo : equipos) {
            if (equipo.getModelo().equals(modelo)) {
                return equipo;
            }
        }
        return null;
    }
     public void agregarVenta(Venta venta) {
        ventas.add(venta);
    }

    public List<Venta> obtenerVentas() {
        return ventas;
    }
  
    
    public List<Equipo> obtenerEquipos() {
        return equipos;}
    // Otros métodos según sea necesario

    public static void main(String[] args) {
        Almacenamiento almacenamiento = new Almacenamiento();

        // Equipos de ejemplo
        Equipo desktop1 = new Equipo("PC Gamer A123", "Desktop", 600, "ATX", 0, 0, "Intel i7", 1000, 16, 1200.0);
        Equipo laptop1 = new Equipo("Laptop Ultraliviano XZY123", "Laptop", 0, "", 15.6, 3, "AMD Ryzen 5", 500, 8, 800.0);
        almacenamiento.agregarEquipo(desktop1);
        almacenamiento.agregarEquipo(laptop1);

        // Menú
        Scanner scanner = new Scanner(System.in);

        int opcion;
        do {
            System.out.println("\nMenú:");
            System.out.println("1. Registrar Cliente");
            System.out.println("2. Registrar Venta");
            System.out.println("3. Mostrar Reportes");
            System.out.println("4. Salir");

            System.out.print("Seleccione una opción: ");
            while (!scanner.hasNextInt()) {
                System.out.print("Por favor, ingrese un número válido: ");
                scanner.next();
            }
            opcion = scanner.nextInt();
            scanner.nextLine();  // Consumir la nueva línea pendiente

            switch (opcion) {
                case 1:
                    // Registrar Cliente
                    System.out.print("Ingrese el Rut del cliente: ");
                    String rutCliente = scanner.nextLine();
                    System.out.print("Ingrese el Nombre completo del cliente: ");
                    String nombreCliente = scanner.nextLine();
                    System.out.print("Ingrese el Correo electrónico del cliente: ");
                    String correoCliente = scanner.nextLine();
                    System.out.print("Ingrese el Teléfono del cliente: ");
                    String telefonoCliente = scanner.nextLine();

                    Cliente nuevoCliente = new Cliente(rutCliente, nombreCliente, correoCliente, telefonoCliente);
                    almacenamiento.agregarCliente(nuevoCliente);

                    System.out.println("Cliente registrado exitosamente.");
                    break;

                case 2:
                    // Registrar Venta
                    System.out.print("Ingrese el Rut del cliente que realiza la compra: ");
                    String rutClienteVenta = scanner.nextLine();
                    Cliente clienteVenta = almacenamiento.obtenerClientePorRut(rutClienteVenta);

                    if (clienteVenta == null) {
                        System.out.println("Cliente no encontrado. Por favor, registre al cliente antes de realizar una venta.");
                        break;
                    }

                    // Mostrar listado de equipos
                    System.out.println("Listado de Equipos Disponibles:");
                    almacenamiento.obtenerEquipos().forEach(e -> System.out.println(e.getModelo()));

                    System.out.print("Ingrese el modelo del equipo que desea comprar: ");
                    String modeloEquipoVenta = scanner.nextLine();
                    Equipo equipoVenta = almacenamiento.obtenerEquipoPorModelo(modeloEquipoVenta);

                    if (equipoVenta == null) {
                        System.out.println("Equipo no encontrado en el inventario. Por favor, seleccione un equipo válido.");
                        break;
                    }

                    Venta nuevaVenta = new Venta(clienteVenta, equipoVenta);
                    almacenamiento.agregarVenta(nuevaVenta);

                    System.out.println("Venta registrada exitosamente.");
                    break;

                case 3:
                    // Mostrar Reportes
                    System.out.println("\nReportes:");
                    System.out.println("1. Listado de Equipos Vendidos");
                    System.out.println("2. Cantidad de Ventas y Monto Total Recaudado");
                    System.out.print("Seleccione una opción de reporte: ");
                    int opcionReporte = scanner.nextInt();

                    switch (opcionReporte) {
                        case 1:
                            // Listado de Equipos Vendidos
                            List<Venta> ventas = almacenamiento.obtenerVentas();
                            System.out.println("Listado de Equipos Vendidos:");
                            for (Venta venta : ventas) {
                                System.out.println("Cliente: " + venta.getCliente().getNombreCompleto());
                                System.out.println("Modelo del Equipo: " + venta.getEquipo().getModelo());
                                System.out.println("Precio del Equipo: $" + venta.getEquipo().getPrecio());
                                System.out.println("Fecha y Hora de la Venta: " + venta.getFechaHora());
                                System.out.println();
                            }
                            break;

                        case 2:
                            // Cantidad de Ventas y Monto Total Recaudado
                            List<Venta> todasLasVentas = almacenamiento.obtenerVentas();
                            int cantidadVentas = todasLasVentas.size();
                            double montoTotalRecaudado = todasLasVentas.stream().mapToDouble(v -> v.getEquipo().getPrecio()).sum();

                            System.out.println("Cantidad de Ventas: " + cantidadVentas);
                            System.out.println("Monto Total Recaudado: $" + montoTotalRecaudado);
                            break;

                        default:
                            System.out.println("Opción no válida.");
                            break;
                    }
                    break;

                case 4:
                    // Salir
                    System.out.println("Saliendo del programa.");
                    break;

                default:
                    System.out.println("Opción no válida. Inténtelo de nuevo.");
            }
        } while (opcion != 4);

        scanner.close();
    }
}