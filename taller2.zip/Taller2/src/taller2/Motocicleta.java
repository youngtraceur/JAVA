/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package taller2;

import java.util.ArrayList;
import java.util.List;

class Motocicleta extends Vehiculo {
    private String estilo;
    private double medidaManillar;

    public Motocicleta(String patente, String marca, String color, double costoNetoDeServicios, String estilo, double medidaManillar) {
        super(patente, marca, color, costoNetoDeServicios);
        this.estilo = estilo;
        this.medidaManillar = medidaManillar;
    }

    @Override
    public void imprimirBoleta() {
        double iva = totalDelIVA();
        double descuento = obtenerDescuento();
        double totalAPagar = costoNetoDeServicios + iva - descuento;

        System.out.println("Boleta para Motocicleta:");
        System.out.println("Patente: " + patente);
        System.out.println("Marca: " + marca);
        System.out.println("Color: " + color);
        System.out.println("Costo Neto de Servicios: " + costoNetoDeServicios);
        System.out.println("Estilo: " + estilo);
        System.out.println("Medida del Manillar: " + medidaManillar);
        System.out.println("IVA: " + iva);
        System.out.println("Descuento: " + descuento);
        System.out.println("Total a Pagar: " + totalAPagar);
    }

    @Override
    public double totalDelIVA() {
        return costoNetoDeServicios * IVA;
    }

    @Override
    public double obtenerDescuento() {
        return costoNetoDeServicios * DESCUENTO_MOTOCICLETA;
    }
}

// Clase RegistroVehiculos
class RegistroVehiculos {
    private List<Vehiculo> vehiculos = new ArrayList<>();

    public void ingresarVehiculo(Vehiculo vehiculo) {
        vehiculos.add(vehiculo);
    }

    public void listarVehiculos() {
        for (Vehiculo vehiculo : vehiculos) {
            vehiculo.imprimirBoleta();
            System.out.println("################");
        }
    }

    public void eliminarVehiculo(String patente) {
        vehiculos.removeIf(vehiculo -> vehiculo.getPatente().equals(patente));
    }
}