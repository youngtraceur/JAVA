/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package taller2;

public class Main {
    public static void main(String[] args) {
        // Crear un registro de vehículos
        RegistroVehiculos registro = new RegistroVehiculos();

        // Registrar dos vehículos y una motocicleta
        // Patente marca color costo puertas litros
        Automovil auto1 = new Automovil("ABCD66", "Toyoya", "gris", 100000, 4, 400);
        Automovil auto2 = new Automovil("XYZZ77", "Lambda", "Azul", 80000, 2, 300);
        Motocicleta moto1 = new Motocicleta("AN897", "ÑIÑUKI", "Negro", 50000, "Enduro", 75);

        registro.ingresarVehiculo(auto1);
        registro.ingresarVehiculo(auto2);
        registro.ingresarVehiculo(moto1);

        // Listar todos los vehículos
        registro.listarVehiculos();

        // Eliminar un vehículo por patente
        registro.eliminarVehiculo("XYZ789");

        // Listar los vehículos nuevamente después de eliminar uno
        System.out.println("Vehículos después de eliminar uno:");
        registro.listarVehiculos();
    }
}