/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package taller2;

class Automovil extends Vehiculo {
    private int cantidadPuertas;
    private int capacidadMaletero;

    public Automovil(String patente, String marca, String color, double costoNetoDeServicios, int cantidadPuertas, int capacidadMaletero) {
        super(patente, marca, color, costoNetoDeServicios);
        this.cantidadPuertas = cantidadPuertas;
        this.capacidadMaletero = capacidadMaletero;
    }

    @Override
    public void imprimirBoleta() {
        double iva = totalDelIVA();
        double descuento = obtenerDescuento();
        double totalAPagar = costoNetoDeServicios + iva - descuento;

        System.out.println("Boleta para Automovil:");
        System.out.println("Patente: " + patente);
        System.out.println("Marca: " + marca);
        System.out.println("Color: " + color);
        System.out.println("Costo Neto de Servicios: " + costoNetoDeServicios);
        System.out.println("Cantidad de Puertas: " + cantidadPuertas);
        System.out.println("Capacidad del Maletero: " + capacidadMaletero);
        System.out.println("IVA: " + iva);
        System.out.println("Descuento: " + descuento);
        System.out.println("Total a Pagar: " + totalAPagar);
    }

    @Override
    public double totalDelIVA() {
        return costoNetoDeServicios * IVA;
    }

    @Override
    public double obtenerDescuento() {
        return costoNetoDeServicios * DESCUENTO_AUTOMOVIL;
    }
}