/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package taller2;

abstract class Vehiculo implements Parametros {
    protected String patente;
    protected String marca;
    protected String color;
    protected double costoNetoDeServicios;

    public Vehiculo(String patente, String marca, String color, double costoNetoDeServicios) {
        this.patente = patente;
        this.marca = marca;
        this.color = color;
        this.costoNetoDeServicios = costoNetoDeServicios;
    }

    public abstract void imprimirBoleta();

    public String getPatente() {
        return patente;
    }
}