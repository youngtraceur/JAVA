package automotora;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        RegistroVehiculos registro = new RegistroVehiculos();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("******Taller Mecanico la LLave Nuda******");
            System.out.println("1. Ingresar vehículo");
            System.out.println("2. Lista de vehículos");
            System.out.println("3. Eliminar un vehículo");
            System.out.println("4. Mostrar cantidad de vehículos");
            System.out.println("5. Salir");
            System.out.print("Selecciona una opción: ");

            int opcion = -1; 
            try {
                opcion = scanner.nextInt();
            } catch (java.util.InputMismatchException e) {
                System.out.println("Opción no válida. Por favor, ingresa un número.");
                scanner.nextLine(); 
                continue;
            }

            scanner.nextLine(); 

            switch (opcion) {
                case 1:
                    String patente;
                    do {
                        System.out.print("Ingrese la patente (máximo 6 caracteres): ");
                        patente = scanner.nextLine();
                        if (patente.length() > 6) {
                            System.out.println("La patente no puede ser mayor a 6 caracteres.");
                        }
                    } while (patente.length() > 6);

                    System.out.print("Ingrese la marca: ");
                    String marca = scanner.nextLine();
                    System.out.print("Ingrese el color: ");
                    String color = scanner.nextLine();

                    int costoNeto = -1;
                    while (true) {
                        System.out.print("Ingrese costo del servicio: ");
                        if (scanner.hasNextInt()) {
                            costoNeto = scanner.nextInt();
                            break;
                        } else {
                            System.out.println("El valor ingresado debe ser numerico");
                            scanner.next(); 
                        }
                    }

                    System.out.print("¿Es un automóvil? (S/N): ");
                    String esAutomovil = scanner.next().toUpperCase();

                    if (esAutomovil.equals("S")) {
                        System.out.print("Cantidad de puertas: ");
                        int cantidadPuertas = scanner.nextInt();

                        int capacidadMaletero = -1;
                        while (true) {
                            System.out.print("Capacidad del maletero (Litros): ");
                            if (scanner.hasNextInt()) {
                                capacidadMaletero = scanner.nextInt();
                                break;
                            } else {
                                System.out.println("La capacidad del maletero debe ser un número!");
                                scanner.next(); 
                            }
                        }

                        Automovil auto = new Automovil(patente, marca, color, costoNeto, cantidadPuertas, capacidadMaletero);
                        registro.ingresarVehiculo(auto);
                    } else {
                        System.out.print("Estilo de la motocicleta: ");
                        String estilo = scanner.next();
                        double medidaManillar = -1;
                        while (true) {
                            System.out.print("Medida del manillar (en Milimetros): ");
                            if (scanner.hasNextDouble()) {
                                medidaManillar = scanner.nextDouble();
                                break;
                            } else {
                                System.out.println("La medida del manillar debe ser un digito!.");
                                scanner.next(); 
                            }
                        }
                        Motocicleta moto = new Motocicleta(patente, marca, color, costoNeto, estilo, medidaManillar);
                        registro.ingresarVehiculo(moto);
                    }
                    break;
                case 2:
                    registro.listarVehiculos();
                    break;
                case 3:
                    System.out.print("Ingrese la patente del vehículo a eliminar: ");
                    String patenteEliminar = scanner.next();
                    registro.eliminarVehiculo(patenteEliminar);
                    break;
                case 4:
                    registro.mostrarCantidadVehiculos();
                    break;
                case 5:
                    scanner.close();
                    System.exit(0);
                default:
                    System.out.println("Opción no válida.");
                    break;
            }
        }
    }
}
