
package automotora;

class Motocicleta extends Vehiculo {
    private String estilo;
    private double medidaManillar;

    public Motocicleta(String patente, String marca, String color, double costoNetoDeServicios, String estilo, double medidaManillar) {
        super(patente, marca, color, costoNetoDeServicios);
        this.estilo = estilo;
        this.medidaManillar = medidaManillar;
    }

    @Override
    public void imprimirBoleta() {
        System.out.println("*************");
        System.out.println("Boleta para Motocicleta:");
        System.out.println("Patente: " + getPatente());
        System.out.println("Marca: " + getMarca());
        System.out.println("Color: " + getColor());
        System.out.println("Costo Neto: " + getCostoNetoDeServicios());
        System.out.println("Descuento: " + getValorDescuento());
        System.out.println("IVA: " + getIvaPorPagar());
        System.out.println("Total a pagar: " + getTotalPorPagar());
    }

    @Override
    public double obtenerDescuento() {
        return getCostoNetoDeServicios() * DESCUENTO_MOTOCICLETA;
    }

    @Override
    public double totalDelIVA() {
        return getCostoNetoDeServicios() * IVA;
    }
}