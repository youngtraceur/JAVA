/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package automotora;

interface Parametros {
    double IVA = 0.19;
    double DESCUENTO_AUTOMOVIL = 0.05;
    double DESCUENTO_MOTOCICLETA = 0.10;

    double totalDelIVA();
    double obtenerDescuento();
}