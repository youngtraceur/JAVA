/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package automotora;

class Automovil extends Vehiculo {
    private int cantidadPuertas;
    private int capacidadMaletero;

    public Automovil(String patente, String marca, String color, double costoNetoDeServicios, int cantidadPuertas, int capacidadMaletero) {
        super(patente, marca, color, costoNetoDeServicios);
        this.cantidadPuertas = cantidadPuertas;
        this.capacidadMaletero = capacidadMaletero;
    }

    @Override
    public void imprimirBoleta() {
        System.out.println("*****************");
        System.out.println("Boleta para Automóvil:");
        System.out.println("Patente: " + getPatente());
        System.out.println("Marca: " + getMarca());
        System.out.println("Color: " + getColor());
        System.out.println("Costo Neto: " + getCostoNetoDeServicios());
        System.out.println("Descuento: " + getValorDescuento());
        System.out.println("IVA: " + getIvaPorPagar());
        System.out.println("Total a pagar: " + getTotalPorPagar());
    }

    @Override
    public double obtenerDescuento() {
        return getCostoNetoDeServicios() * DESCUENTO_AUTOMOVIL;
    }

    @Override
    public double totalDelIVA() {
        return getCostoNetoDeServicios() * IVA;
    }
}
