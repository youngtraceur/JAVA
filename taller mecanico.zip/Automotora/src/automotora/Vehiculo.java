
package automotora;

abstract class Vehiculo implements Parametros {
    private String patente;
    private String marca;
    private String color;
    private double costoNetoDeServicios;
    private double valorDescuento;
    private double ivaPorPagar;
    private double totalPorPagar;

    public Vehiculo(String patente, String marca, String color, double costoNetoDeServicios) {
        this.patente = patente;
        this.marca = marca;
        this.color = color;
        this.costoNetoDeServicios = costoNetoDeServicios;
        this.valorDescuento = obtenerDescuento();
        this.ivaPorPagar = totalDelIVA();
        this.totalPorPagar = costoNetoDeServicios - valorDescuento + ivaPorPagar;
    }

    public abstract void imprimirBoleta();

    public String getPatente() {
        return patente;
    }

    public String getMarca() {
        return marca;
    }

    public String getColor() {
        return color;
    }

    public double getCostoNetoDeServicios() {
        return costoNetoDeServicios;
    }

    public double getValorDescuento() {
        return valorDescuento;
    }

    public double getIvaPorPagar() {
        return ivaPorPagar;
    }

    public double getTotalPorPagar() {
        return totalPorPagar;
    }
}
