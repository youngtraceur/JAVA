/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package automotora;

import java.util.ArrayList;
import java.util.List;

class RegistroVehiculos {
    private List<Vehiculo> vehiculos = new ArrayList<>();

    public void ingresarVehiculo(Vehiculo vehiculo) {
        for (Vehiculo v : vehiculos) {
            if (v.getPatente().equals(vehiculo.getPatente())) {
                System.out.println("El vehículo con patente " + vehiculo.getPatente() + " ya existe.");
                return;
            }
        }
        vehiculos.add(vehiculo);
    }

    public void listarVehiculos() {
        for (Vehiculo vehiculo : vehiculos) {
            vehiculo.imprimirBoleta();
        }
    }

    public void eliminarVehiculo(String patente) {
        Vehiculo vehiculoAEliminar = null;
        for (Vehiculo vehiculo : vehiculos) {
            if (vehiculo.getPatente().equals(patente)) {
                vehiculoAEliminar = vehiculo;
                break;
            }
        }
        if (vehiculoAEliminar != null) {
            vehiculos.remove(vehiculoAEliminar);
            System.out.println("Vehículo con patente " + patente + " eliminado.");
        } else {
            System.out.println("No se encontró ningún vehículo con la patente " + patente);
        }
    }

    public void mostrarCantidadVehiculos() {
        int cantidadAutomoviles = 0;
        int cantidadMotocicletas = 0;
        for (Vehiculo vehiculo : vehiculos) {
            if (vehiculo instanceof Automovil) {
                cantidadAutomoviles++;
            } else if (vehiculo instanceof Motocicleta) {
                cantidadMotocicletas++;
            }
        }
        System.out.println("******************");
        System.out.println("******************");
        System.out.println("Cantidad de Automóviles: " + cantidadAutomoviles);
        System.out.println("Cantidad de Motocicletas: " + cantidadMotocicletas);
    }
}