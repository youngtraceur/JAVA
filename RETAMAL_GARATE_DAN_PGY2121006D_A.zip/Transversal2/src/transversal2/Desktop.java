/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package transversal2;

public class Desktop extends Equipo {
    private int potenciaFuentePoder;
    private String factorForma;

    public Desktop(String descripcionModelo, String cpu, int tamañoDiscoDuroMB, int cantidadRamGB, double precio,
                   int potenciaFuentePoder, String factorForma) {
        super(descripcionModelo, cpu, tamañoDiscoDuroMB, cantidadRamGB, precio);
        this.potenciaFuentePoder = potenciaFuentePoder;
        this.factorForma = factorForma;
    }

    // Getters y setters
    public int getPotenciaFuentePoder() {
        return potenciaFuentePoder;
    }

    public void setPotenciaFuentePoder(int potenciaFuentePoder) {
        this.potenciaFuentePoder = potenciaFuentePoder;
    }

    public String getFactorForma() {
        return factorForma;
    }

    public void setFactorForma(String factorForma) {
        this.factorForma = factorForma;
    }
}
