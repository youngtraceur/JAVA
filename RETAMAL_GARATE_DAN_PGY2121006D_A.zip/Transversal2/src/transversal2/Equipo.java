/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package transversal2;
public abstract class Equipo {
    private String descripcionModelo;
    private String cpu;
    private int tamañoDiscoDuroMB;
    private int cantidadRamGB;
    private double precio;

    public Equipo(String descripcionModelo, String cpu, int tamañoDiscoDuroMB, int cantidadRamGB, double precio) {
        this.descripcionModelo = descripcionModelo;
        this.cpu = cpu;
        this.tamañoDiscoDuroMB = tamañoDiscoDuroMB;
        this.cantidadRamGB = cantidadRamGB;
        this.precio = precio;
    }

    // Getters y setters
    public String getDescripcionModelo() {
        return descripcionModelo;
    }

    public void setDescripcionModelo(String descripcionModelo) {
        this.descripcionModelo = descripcionModelo;
    }

    public String getCpu() {
        return cpu;
    }

    public void setCpu(String cpu) {
        this.cpu = cpu;
    }

    public int getTamañoDiscoDuroMB() {
        return tamañoDiscoDuroMB;
    }

    public void setTamañoDiscoDuroMB(int tamañoDiscoDuroMB) {
        this.tamañoDiscoDuroMB = tamañoDiscoDuroMB;
    }

    public int getCantidadRamGB() {
        return cantidadRamGB;
    }

    public void setCantidadRamGB(int cantidadRamGB) {
        this.cantidadRamGB = cantidadRamGB;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }
}
