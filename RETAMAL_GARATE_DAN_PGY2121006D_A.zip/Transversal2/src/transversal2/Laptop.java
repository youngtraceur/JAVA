/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package transversal2;

public class Laptop extends Equipo {
    private double tamañoPantallaPulgadas;
    private int cantidadPuertosUSB;

    public Laptop(String descripcionModelo, String cpu, int tamañoDiscoDuroMB, int cantidadRamGB, double precio,
                  double tamañoPantallaPulgadas, int cantidadPuertosUSB) {
        super(descripcionModelo, cpu, tamañoDiscoDuroMB, cantidadRamGB, precio);
        this.tamañoPantallaPulgadas = tamañoPantallaPulgadas;
        this.cantidadPuertosUSB = cantidadPuertosUSB;
    }

    // Getters y setters
    public double getTamañoPantallaPulgadas() {
        return tamañoPantallaPulgadas;
    }

    public void setTamañoPantallaPulgadas(double tamañoPantallaPulgadas) {
        this.tamañoPantallaPulgadas = tamañoPantallaPulgadas;
    }

    public int getCantidadPuertosUSB() {
        return cantidadPuertosUSB;
    }

    public void setCantidadPuertosUSB(int cantidadPuertosUSB) {
        this.cantidadPuertosUSB = cantidadPuertosUSB;
    }
}
