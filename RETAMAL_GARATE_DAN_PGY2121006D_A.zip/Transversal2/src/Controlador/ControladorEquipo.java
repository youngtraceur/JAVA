/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import java.util.List;
import transversal2.Almacenamiento;
import transversal2.Equipo;

public class ControladorEquipo {

    private Almacenamiento almacenamiento;

    public ControladorEquipo(Almacenamiento almacenamiento) {
        this.almacenamiento = almacenamiento;
    }

    public void registrarNuevoEquipo(Equipo equipo) {
        almacenamiento.agregarEquipo(equipo);
    }

    public Equipo obtenerEquipoPorModelo(String modelo) {
        return almacenamiento.obtenerEquipoPorModelo(modelo);
    }

    public List<Equipo> obtenerTodosLosEquipos() {
        return almacenamiento.obtenerEquipos();
    }

    // Otros métodos según sea necesario
}
