/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import java.util.List;
import transversal2.Almacenamiento;
import transversal2.Cliente;

public class ControladorCliente {

    private Almacenamiento almacenamiento;

    public ControladorCliente(Almacenamiento almacenamiento) {
        this.almacenamiento = almacenamiento;
    }

    public void registrarNuevoCliente(Cliente cliente) {
        almacenamiento.agregarCliente(cliente);
    }

    public Cliente obtenerClientePorRut(String rut) {
        return almacenamiento.obtenerClientePorRut(rut);
    }

    public List<Cliente> obtenerTodosLosClientes() {
        return almacenamiento.obtenerClientes();
    }

    // Otros métodos según sea necesario
}
