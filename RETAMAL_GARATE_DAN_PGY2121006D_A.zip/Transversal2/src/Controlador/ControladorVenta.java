/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import java.util.Date;
import java.util.List;
import transversal2.Almacenamiento;
import transversal2.Cliente;
import transversal2.Equipo;
import transversal2.Venta;

public class ControladorVenta {

    private Almacenamiento almacenamiento;

    public ControladorVenta(Almacenamiento almacenamiento) {
        this.almacenamiento = almacenamiento;
    }

    public void registrarNuevaVenta(Cliente cliente, Equipo equipo) {
        Date fechaHoraVenta = new Date();  // Puedes usar una librería específica para manejar fechas y horas
        Venta nuevaVenta = new Venta(cliente, equipo, fechaHoraVenta);
        almacenamiento.agregarVenta(nuevaVenta);
    }

    public List<Venta> obtenerTodasLasVentas() {
        return almacenamiento.obtenerVentas();
    }

    // Otros métodos según sea necesario
}
