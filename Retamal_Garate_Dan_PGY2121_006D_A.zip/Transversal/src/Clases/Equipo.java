/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

public abstract class Equipo {
    private String modelo;
    private String cpu;
    private int tamanoDisco;
    private int cantidadRam;
    private double precio;

    public Equipo(String modelo, String cpu, int tamanoDisco, int cantidadRam, double precio) {
        this.modelo = modelo;
        this.cpu = cpu;
        this.tamanoDisco = tamanoDisco;
        this.cantidadRam = cantidadRam;
        this.precio = precio;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getCpu() {
        return cpu;
    }

    public void setCpu(String cpu) {
        this.cpu = cpu;
    }

    public int getTamanoDisco() {
        return tamanoDisco;
    }

    public void setTamanoDisco(int tamanoDisco) {
        this.tamanoDisco = tamanoDisco;
    }

    public int getCantidadRam() {
        return cantidadRam;
    }

    public void setCantidadRam(int cantidadRam) {
        this.cantidadRam = cantidadRam;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }
}