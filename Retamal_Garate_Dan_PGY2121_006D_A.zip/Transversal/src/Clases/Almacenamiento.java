/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

import java.util.ArrayList;
import java.util.List;

public class Almacenamiento {
    private List<Cliente> clientes;
    private List<Equipo> equipos;
    private List<Venta> ventas;

    public Almacenamiento() {
        this.clientes = new ArrayList<>();
        this.equipos = new ArrayList<>();
        this.ventas = new ArrayList<>();
    }

    // Métodos para agregar, obtener y buscar clientes, equipos y ventas

    // Métodos para clientes
    public void agregarCliente(Cliente cliente) {
        clientes.add(cliente);
    }

    public Cliente obtenerClientePorRut(String rut) {
        for (Cliente cliente : clientes) {
            if (cliente.getRut().equals(rut)) {
                return cliente;
            }
        }
        return null;
    }

    // Método para equipos
    public void agregarEquipo(Equipo equipo) {
        equipos.add(equipo);
    }

    public Equipo obtenerEquipoPorModelo(String modelo) {
        for (Equipo equipo : equipos) {
            if (equipo.getModelo().equals(modelo)) {
                return equipo;
            }
        }
        return null;
    }

    // Método para ventas
    public void agregarVenta(Venta venta) {
        ventas.add(venta);
    }

    public Venta obtenerVentaPorClienteYEquipo(Cliente cliente, Equipo equipo) {
        for (Venta venta : ventas) {
            if (venta.getCliente().equals(cliente) && venta.getEquipo().equals(equipo)) {
                return venta;
            }
        }
        return null;
    }

    // Otros métodos según sea necesario
}