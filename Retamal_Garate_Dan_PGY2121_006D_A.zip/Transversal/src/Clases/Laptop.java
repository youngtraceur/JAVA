/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

public class Laptop extends Equipo {
    private double tamanoPantalla;
    private int cantidadPuertosUSB;

    public Laptop(String modelo, String cpu, int tamanoDisco, int cantidadRam, double precio,
                  double tamanoPantalla, int cantidadPuertosUSB) {
        super(modelo, cpu, tamanoDisco, cantidadRam, precio);
        this.tamanoPantalla = tamanoPantalla;
        this.cantidadPuertosUSB = cantidadPuertosUSB;
    }

    public double getTamanoPantalla() {
        return tamanoPantalla;
    }

    public void setTamanoPantalla(double tamanoPantalla) {
        this.tamanoPantalla = tamanoPantalla;
    }

    public int getCantidadPuertosUSB() {
        return cantidadPuertosUSB;
    }

    public void setCantidadPuertosUSB(int cantidadPuertosUSB) {
        this.cantidadPuertosUSB = cantidadPuertosUSB;
    }
}