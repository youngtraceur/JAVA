/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class InterfazGrafica {
    private Almacenamiento almacenamiento;

    public InterfazGrafica(Almacenamiento almacenamiento) {
        this.almacenamiento = almacenamiento;
    }

    public void mostrarInterfaz() {
        JFrame frame = new JFrame("Sistema de Ventas Computec");
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JMenuBar menuBar = new JMenuBar();
        JMenu menuClientes = new JMenu("Clientes");
        JMenu menuEquipos = new JMenu("Equipos");
        JMenu menuVentas = new JMenu("Ventas");

        JMenuItem itemAgregarCliente = new JMenuItem("Agregar Cliente");
        JMenuItem itemObtenerCliente = new JMenuItem("Obtener Cliente");
        JMenuItem itemBuscarCliente = new JMenuItem("Buscar Cliente");

        JMenuItem itemAgregarEquipo = new JMenuItem("Agregar Equipo");
        JMenuItem itemObtenerEquipo = new JMenuItem("Obtener Equipo");
        JMenuItem itemBuscarEquipo = new JMenuItem("Buscar Equipo");

        JMenuItem itemAgregarVenta = new JMenuItem("Agregar Venta");
        JMenuItem itemObtenerVenta = new JMenuItem("Obtener Venta");
        JMenuItem itemBuscarVenta = new JMenuItem("Buscar Venta");

        itemAgregarCliente.addActionListener(e -> agregarCliente());
        itemObtenerCliente.addActionListener(e -> obtenerCliente());
        itemBuscarCliente.addActionListener(e -> buscarCliente());

        itemAgregarEquipo.addActionListener(e -> agregarEquipo());
        itemObtenerEquipo.addActionListener(e -> obtenerEquipo());
        itemBuscarEquipo.addActionListener(e -> buscarEquipo());

        itemAgregarVenta.addActionListener(e -> agregarVenta());
        itemObtenerVenta.addActionListener(e -> obtenerVenta());
        itemBuscarVenta.addActionListener(e -> buscarVenta());

        menuClientes.add(itemAgregarCliente);
        menuClientes.add(itemObtenerCliente);
        menuClientes.add(itemBuscarCliente);

        menuEquipos.add(itemAgregarEquipo);
        menuEquipos.add(itemObtenerEquipo);
        menuEquipos.add(itemBuscarEquipo);

        menuVentas.add(itemAgregarVenta);
        menuVentas.add(itemObtenerVenta);
        menuVentas.add(itemBuscarVenta);

        menuBar.add(menuClientes);
        menuBar.add(menuEquipos);
        menuBar.add(menuVentas);

        frame.setJMenuBar(menuBar);
        frame.setVisible(true);
    }

    private void agregarCliente() {
        // Implementa la lógica para agregar un cliente
    }

    private void obtenerCliente() {
        // Implementa la lógica para obtener un cliente
    }

    private void buscarCliente() {
        // Implementa la lógica para buscar un cliente
    }

    private void agregarEquipo() {
        // Implementa la lógica para agregar un equipo
    }

    private void obtenerEquipo() {
        // Implementa la lógica para obtener un equipo
    }

    private void buscarEquipo() {
        // Implementa la lógica para buscar un equipo
    }

    private void agregarVenta() {
        // Implementa la lógica para agregar una venta
    }

    private void obtenerVenta() {
        // Implementa la lógica para obtener una venta
    }

    private void buscarVenta() {
        // Implementa la lógica para buscar una venta
    }

    public static void main(String[] args) {
        Almacenamiento almacenamiento = new Almacenamiento();
        InterfazGrafica interfaz = new InterfazGrafica(almacenamiento);
        SwingUtilities.invokeLater(() -> interfaz.mostrarInterfaz());
    }
}